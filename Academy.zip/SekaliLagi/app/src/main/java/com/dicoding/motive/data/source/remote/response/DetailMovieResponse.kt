package com.dicoding.motive.data.source.remote.response

import com.dicoding.motive.data.source.local.entity.DetailMovieEntity


data class DetailMovieResponse(
        val results: ArrayList<DetailMovieEntity>
)

