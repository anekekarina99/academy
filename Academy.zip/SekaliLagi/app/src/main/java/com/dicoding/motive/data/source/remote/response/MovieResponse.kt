package com.dicoding.motive.data.source.remote.response

import com.dicoding.motive.data.source.local.entity.MovieEntity

data class MovieResponse(
        val results: ArrayList<MovieEntity>
)