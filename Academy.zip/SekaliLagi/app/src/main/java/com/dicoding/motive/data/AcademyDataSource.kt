package com.dicoding.motive.data


import androidx.lifecycle.LiveData
import com.dicoding.motive.data.source.local.entity.DetailMovieEntity
import com.dicoding.motive.data.source.local.entity.DetailTvEntity
import com.dicoding.motive.data.source.local.entity.MovieEntity
import com.dicoding.motive.data.source.local.entity.TvEntity

interface AcademyDataSource {

    fun getMoviePopular(): LiveData<ArrayList<MovieEntity>>

    fun getMovieDetail(id : Int): LiveData<DetailMovieEntity>

    fun getTvPopular(): LiveData<ArrayList<TvEntity>>

    fun getTvDetail(id : Int): LiveData<DetailTvEntity>
}