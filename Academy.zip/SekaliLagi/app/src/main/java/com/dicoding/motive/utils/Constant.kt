package com.dicoding.motive.utils

class Constant {

    companion object{
        const val API_KEY = "5829da11901d652c0ebdcb4c5bfa7015";
        const val BASE_URL = "https://api.themoviedb.org/3/";
        const val POSTER_BASE_URL = "https://image.tmdb.org/t/p/w342";

    }
}