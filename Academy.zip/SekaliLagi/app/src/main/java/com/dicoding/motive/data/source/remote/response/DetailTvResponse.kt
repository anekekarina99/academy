package com.dicoding.motive.data.source.remote.response

import com.dicoding.motive.data.source.local.entity.DetailTvEntity


data class DetailTvResponse(
        val results: ArrayList<DetailTvEntity>
)
