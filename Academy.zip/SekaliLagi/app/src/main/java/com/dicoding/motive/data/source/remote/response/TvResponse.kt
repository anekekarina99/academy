package com.dicoding.motive.data.source.remote.response


import com.dicoding.motive.data.source.local.entity.TvEntity


data class TvResponse(
        val results: ArrayList<TvEntity>
)

