package com.dicoding.motive.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.motive.data.AcademyRepository
import com.dicoding.motive.data.source.local.entity.DetailMovieEntity
import kotlin.properties.Delegates

class DetailViewModel(private val academyRepository: AcademyRepository) : ViewModel() {
    var id by Delegates.notNull<Int>()

    fun setSelectedCourse(id: Int) {
        this.id = id
    }

    fun getMovieDetail(): LiveData<DetailMovieEntity> = academyRepository.getMovieDetail(id)

}


