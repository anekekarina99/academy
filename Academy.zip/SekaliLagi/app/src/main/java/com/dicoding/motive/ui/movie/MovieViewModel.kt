package com.dicoding.motive.ui.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.motive.data.AcademyRepository
import com.dicoding.motive.data.source.local.entity.MovieEntity

class MovieViewModel(private val academyRepository: AcademyRepository) : ViewModel() {

    fun getMovie(): LiveData<ArrayList<MovieEntity>> = academyRepository.getMoviePopular()
}

