package com.dicoding.motive.di

import android.content.Context

import com.dicoding.motive.data.AcademyRepository
import com.dicoding.motive.data.source.remote.RemoteDataSource

object Injection {
    fun provideRepository(context: Context): AcademyRepository {

        val remoteRepository = RemoteDataSource.getInstance()

        return AcademyRepository.getInstance(remoteRepository)
    }
}
